package com.sample.webclient;

import lombok.Data;

@Data
public class Account {

	private Long id;
	private Long amount;
	private String number;
	private String name;
}
