package com.sample.webclient;

import java.util.List;

public interface AccountClient {

	List<Account> getAllAccounts();

	Account getAccount(String number);
}
