package com.sample.account;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountServiceController {
	
	protected Logger logger = Logger.getLogger(AccountServiceController.class.getName());
	
	@Autowired
	AccountRepository accountRepository;
	
	@GetMapping("/accounts")
	public List<Account> all() {
		logger.info("accounts-microservice all() invoked");
		List<Account> accounts = accountRepository.findAll();
		logger.info("accounts-microservice all() found: " + accounts.size());
		return accounts;
	}
	
	@GetMapping("/accounts/{id}")
	public Account byId(@PathVariable("id") String id) {
		logger.info("accounts-microservice byId() invoked: " + id);
		Account account = accountRepository.findAll()
				.stream()
				.filter(i -> i.getNumber().equalsIgnoreCase(id)).findFirst().get();
		logger.info("accounts-microservice byId() found: " + account);
		return account;
	}

}
