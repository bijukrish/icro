insert into Account(id,amount,number,name) values (1, 786,'5001','Raj Kumar');
insert into Account(id,amount,number,name) values (2, 34566,'5003','Sagar');
insert into Account(id,amount,number,name) values (3, 236777,'5002','Krishnan');